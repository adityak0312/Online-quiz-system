let g=document.getElementById("texta");
let count=0;

let k=document.getElementById("1");
k.addEventListener('click',()=>{
        k.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    })


    
    let q=document.getElementById("2");

    q.addEventListener('click',()=>{
        q.style.backgroundColor="red";
    });
    let p=document.getElementById("3");

    p.addEventListener('click',()=>{
        p.style.backgroundColor="red";
    });
    let r=document.getElementById("4");

    r.addEventListener('click',()=>{
        r.style.backgroundColor="red";
    }); 
    let seca=document.getElementById("6");
    seca.addEventListener('click',()=>{
            seca.style.backgroundColor="green";
            count=count+1;
            console.log(count);
            g.innerHTML=count;
        });
    
    
        
        let secb=document.getElementById("5");
    
        secb.addEventListener('click',()=>{
            secb.style.backgroundColor="red";
        });
        let secc=document.getElementById("7");
    
        secc.addEventListener('click',()=>{
            secc.style.backgroundColor="red";
        });
        let secd=document.getElementById("8");
    
        secd.addEventListener('click',()=>{
            secd.style.backgroundColor="red";
        }); 
        let thirda=document.getElementById("11");
thirda.addEventListener('click',()=>{
        thirda.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    });


    
    let thirdb=document.getElementById("10");

    thirdb.addEventListener('click',()=>{
        thirdb.style.backgroundColor="red";
    });
    let thirdc=document.getElementById("9");

    thirdc.addEventListener('click',()=>{
        thirdc.style.backgroundColor="red";
    });
    let thirdd=document.getElementById("12");

    thirdd.addEventListener('click',()=>{
        thirdd.style.backgroundColor="red";
    }); 
    let fortha=document.getElementById("14");
fortha.addEventListener('click',()=>{
        fortha.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    });


    
    let forthb=document.getElementById("13");

    forthb.addEventListener('click',()=>{
        forthb.style.backgroundColor="red";
    });
    let forthc=document.getElementById("15");

    forthc.addEventListener('click',()=>{
        forthc.style.backgroundColor="red";
    });
    let forthd=document.getElementById("16");

    forthd.addEventListener('click',()=>{
        forthd.style.backgroundColor="red";
    }); 
    let fiftha=document.getElementById("20");
    fiftha.addEventListener('click',()=>{
        fiftha.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    });


    
    let fifthb=document.getElementById("19");

    fifthb.addEventListener('click',()=>{
        fifthb.style.backgroundColor="red";
    });
    let fifthc =document.getElementById("17");

    fifthc.addEventListener('click',()=>{
        fifthc.style.backgroundColor="red";
    });
    let fifthd=document.getElementById("18");

    fifthd.addEventListener('click',()=>{
        fifthd.style.backgroundColor="red";
    }); 
    let sixa=document.getElementById("21");
sixa.addEventListener('click',()=>{
        sixa.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    });


    
    let sixb=document.getElementById("22");

    sixb.addEventListener('click',()=>{
        sixb.style.backgroundColor="red";
    });
    let sixc=document.getElementById("23");

    sixc.addEventListener('click',()=>{
        sixc.style.backgroundColor="red";
    });
    let sixd=document.getElementById("24");

    sixd.addEventListener('click',()=>{
        sixd.style.backgroundColor="red";
    }); 
    let sevena=document.getElementById("28");
    sevena.addEventListener('click',()=>{
        sevena.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    });


    
    let sevenb=document.getElementById("25");

    sevenb.addEventListener('click',()=>{
        sevenb.style.backgroundColor="red";
    });
    let sevenc=document.getElementById("26");

    sevenc.addEventListener('click',()=>{
        sevenc.style.backgroundColor="red";
    });
    let sevend=document.getElementById("27");

    sevend.addEventListener('click',()=>{
        sevend.style.backgroundColor="red";
    }); 
    let eighta=document.getElementById("29");
       eighta.addEventListener('click',()=>{
        eighta.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    });


    
    let eightb=document.getElementById("30");eightb
    eightb.addEventListener('click',()=>{
        eightb.style.backgroundColor="red";
    });
    let eightc=document.getElementById("31");

    eightc.addEventListener('click',()=>{
        eightc.style.backgroundColor="red";
    });
    let eightd=document.getElementById("32");eightd
    eightd.addEventListener('click',()=>{
        eightd.style.backgroundColor="red";
    }); 

    let ninea=document.getElementById("35");
ninea.addEventListener('click',()=>{
        ninea.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    });


    
    let nineb=document.getElementById("33");

    nineb.addEventListener('click',()=>{
        nineb.style.backgroundColor="red";
    });
    let ninec=document.getElementById("34");

    ninec.addEventListener('click',()=>{
        ninec.style.backgroundColor="red";
    });
    let nined=document.getElementById("36");

    nined.addEventListener('click',()=>{
        nined.style.backgroundColor="red";
    });
    let tena=document.getElementById("38");
tena.addEventListener('click',()=>{
        tena.style.backgroundColor="green";
        count=count+1;
        console.log(count);
        g.innerHTML=count;
    });


    
    let tenb=document.getElementById("37");

    tenb.addEventListener('click',()=>{
        tenb.style.backgroundColor="red";
    });
    let tenc=document.getElementById("39");

    tenc.addEventListener('click',()=>{
        tenc.style.backgroundColor="red";
    });
    let tend=document.getElementById("40");

    tend.addEventListener('click',()=>{
        tend.style.backgroundColor="red";
    }); 


// let a=document.querySelectorAll("button");

// function Press(btnvalue){
//     if(btnvalue==1){
//         button.style.backgroundColor="green";
//     }
//     else{
//         button.style.backgroundColor="red";
//     }
// }
// a.forEach((button) => {
// button.addEventListener('click',(e)=>Press(e.target.value));
// });
// let a=document.querySelectorAll("button");
// console.log(a);
// function press(btnvalue){
//     if(btnvalue === 1){
//         button.style.backgroundColor="green";
//     }
//     else{
//         button.style.backgroundColor="red";
//     }
// };  
// a.forEach((button) => {
//     button.addEventListener("click",(e)=>press(e.target.value));
// });
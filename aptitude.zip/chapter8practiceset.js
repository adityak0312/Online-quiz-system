let k=document.body.firstElementChild;
k.onclick=(e)=>alert("you are first ");
let p=k.nextElementSibling;
p.onclick=(e)=>alert("you are second");
let g=p.nextElementSibling;
g.onclick=(e)=>alert("you are third");

let t=document.getElementById("google");
console.log(t)
t.addEventListener('click',function(){
    // var url="https://www.google.com";
    // window.location="https://www.google.com";
    // win.focus();
    window.open("calculator.html");
});
function showtime(){
const a=new Date();
const h=a.getHours();
const m=a.getMinutes();
const s=a.getSeconds();
const da=a.getDay();
const month=a.getMonth();
console.log(h,m,s,da,month);
document.getElementById("hour").innerHTML=h;
document.getElementById("minute").innerHTML=m;
document.getElementById("second").innerHTML=s;
document.getElementById("day").innerHTML=da;
document.getElementById("month").innerHTML=month;
};
setInterval('showtime()',1000);
// document.getElementById("date").addExventListener

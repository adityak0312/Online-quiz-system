// let x = Math.random();
// let k=document.getElementsByClassName("first");
// let a = ["Which is faster, hot or cold? Hot, because you can catch cold.", "What did one plate say to the other plate? Dinner's on me.", "Why do oranges wear sunscreen? So they don't peel.", "My wife told me to stop acting like a flamingo, so I had to put my foot down.", "What do you call a pig that does karate? A pork chop.", "Where does Batman go to the bathroom? The batroom.", "What do you call a pony with a sore throat? A little horse.", "What did the left eye say to the right eye? Between you and me, something smells.", "What did the mama tomato say to the baby tomato? Catch up!", "What do you call a fake noodle? An impasta."];
// let y = Math.floor(Math.random() * (a.length - 1));
// console.log(k);
// k.innerHTML=a[y].k;
let myjokes = ["patna me chut ka ghatana","preeti","pel pelan chapra siwan",
"fatal bur samastipur",
"rahlan jhaath bhar dikhailan haath bhar",
"jhaathe na chuchi baatein uchi uchi",
"ek budhiya bachpan mein mar gaii",
"mar deham sata ke kachiya hata ke",
"Why couldn't the sunflower ride its bike? It lost its petals.",
"What's an egg's favorite vacation spot? New Yolk City.",
"I ate a sock yesterday. It was very time-consuming.",
"What kind of candy do astronauts like? Mars bars.",
"I wanted to buy some camo pants but couldn't find any."]
  
console.log(myjokes.length)
  let index = Math.floor(Math.random() * (myjokes.length-1))
  console.log(index);   
  joke.innerHTML=myjokes[index];
  